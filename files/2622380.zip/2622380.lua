addappid(2622380)
addappid(2622381,0,"c3e9ccfedcda0cd10e53938e15261130b2e166007d2ca8f13aa5a05f06bd2630")
addappid(2622383,0,"c6e496ba5ae5c8bfa358f3a7d923ec39964fa0a41c4fa77006249fe34e677af2")
setManifestid(2622381,"9139632565061756864")
setManifestid(2622383,"818727658284817322")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]