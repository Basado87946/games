addappid(1401730)
addappid(1401731,0,"9feb5500bb35f27058f1c86e3a465a1f4904b2f5abe5ff891a9928cb702fea64")
setManifestid(1401731,"4923106185780332668")





--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]