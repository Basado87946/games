-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3942480)
addappid(3942481,0,"b45fb23c7cd70e0b1489d1cb6218a78ce90fb901c8c25141e7037dfbd0f73edf")