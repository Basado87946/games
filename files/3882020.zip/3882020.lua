-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3882020)
addappid(3882021,0,"3e0f02de49ca52823933dc33882d102ec574582e218684772fb47e86f760ba32")
addappid(4006550,0,"f6970b6cf611267e02442adcd7d26f06ab42b619fcf77cbf2b82074db118373d")