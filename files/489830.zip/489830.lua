-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(489830)
addappid(489830,0,"6a555c63251bd00d634428e538ae4b14e1443b71950e17cf1822a9a4efebaa4c")
addappid(489831,0,"a26da9ff1f2af2345ebfad1bd62bcb9ed1cbe6afcf4ced92d1a5fa944242b825")
addappid(489832,0,"c6c5e29627073060ccf9fc8c6c9c7ec86dfdf16b51b3d1fbb0a2e7c1ad9f533e")
addappid(489833,0,"7c5e75890b4f59b4be2d3b68c88abad8b23b159a23bf25a00c5c3a4748752f36")
addappid(489834,0,"eeb89a10bdac7b9b83b6d03cffd9c6225d9041a8130ea52ff0f96b7f6174e857")
addappid(489835,0,"ed764444d4ab7b8d2f98100ddd951659a57f5df3c8825b2d14df99f8ab1b6447")
addappid(489836,0,"1ebc81b82a20b369c9c0335ed96a206b81b46846f2dc9a9f457e748d1ec48045")
addappid(489837,0,"b2cf2cc8cadda88f33e707b79fb2b95b458553a6d768f7d1ab9ef657a18fa90c")
addappid(489838,0,"807c9db0782a0d03abbe9f123179b7428bb952dcb3c127abcb0455d65d772cdd")
addappid(489839,0,"19028a477ba63d9a671eed7c6590e607370062aa3bf59446cc8b79022ab64de4")
addappid(489891,0,"a74b3e03e4317a8da8f38a17c2d3d411f99f48f6930579c87b9bf03592cf1e4e")