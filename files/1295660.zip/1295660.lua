-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1295660)
addappid(1295661,0,"59cf929fe0be7af1bba7498247138b359bcc8141d6921f65f06f5d3c4e604430")
addappid(1295662,0,"2d91bb0ac40f79f21d133921c8092cee1bbc5622c1e429d5d5e65a5543a440eb")
addappid(1295663,0,"129446ed0c86a3cecf211aca2aca7c0ef0b14248fe2e7229afb79e90f2b07531")
addappid(1295665,0,"ad00cf603a7538a190b6f7e523a9f9b1ff48759aacb39f2b35a70c5302fcef37")
addappid(1295666,0,"68e1686bc8f5a23173a86f6a5c3fb61ae2714081bf956976f7f837a1f03a9779")