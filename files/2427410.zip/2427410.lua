addappid(2427410)
addappid(2427411,0,"b846b553ca61c86d7281f7f121dab3628adebb5655e6bb80262c1a06780f14a6")
setManifestid(2427411,"7440211536964657621")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]