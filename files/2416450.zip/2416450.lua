-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2416450)
addappid(3879490)
addappid(3912890)
addappid(3879491,0,"a609219532d6690630d1cccd2eb190817cca2d15d8380c0d3ba2bb1d91108f67")
addappid(2416451,0,"c52f8369321c8357293962eacf7c7f416c2ea912c3d2640703880a12c964732a")
addappid(3912890)