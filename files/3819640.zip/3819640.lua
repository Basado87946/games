-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3819640)
addappid(3819641,0,"cd3a3b0b3ca76fc3fd11c8c5426cc433df4d406d30e4d4fce18621a4742cdd64")