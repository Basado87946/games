addappid(2776940)
addappid(2776941,0,"5405af9cbdda39dc278fb8dd7b2dca27fc7c9f441a61a3487c8ae40ea29199ad")
setManifestid(2776941,"2165618518356813725")



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]