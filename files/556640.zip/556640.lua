-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(556640)
addappid(556641,0,"039ccae2122280fff2da563de8b26a4813688868e4354ab5aa8b7139bfbbf74a")