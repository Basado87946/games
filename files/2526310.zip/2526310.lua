addappid(2526310)
addappid(2526311,0,"4d96d2024ac336424c26d995e45c7d983e97f71552e8d67e3d794e182b21fc57")
setManifestid(2526311,"2087163512125533778")



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]