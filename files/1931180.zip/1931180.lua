addappid(1931180)
addappid(1931181, 1, "e3b3d8902ae9814c4521fa2a3538b10d43c1fea4f712aa229f22d826ccd8ee6e")
setManifestid(1931181, "6482204933461843804", 0)




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]