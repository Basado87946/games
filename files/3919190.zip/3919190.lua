-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3919190)
addappid(3919191,0,"c7868d4c1ddbf45ef00d72a4f8fd1fb2c7eb7b391499debc8871392ba6e59105")