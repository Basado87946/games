addappid(3489700)
addappid(3489701,0,"2266ca31f6f2666ebe75906201e72f9398694030ff1c8214aacebcf74dc94ee3")
setManifestid(3489701,"1840880717473894999")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]