addappid(2543180)
addappid(2543181,0,"710ea94ede6b7341fc677cfed501f4a587ea3d576e9cecd917f056937548d455")
setManifestid(2543181,"4511471162307097282")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]